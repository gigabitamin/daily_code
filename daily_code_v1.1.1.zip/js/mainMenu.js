// #mainMenuBox li:hover {
// 	background-color: blue;
// 	color: white;
// }

// #mainMenuBox ul li a:hover {
// 	background-color: blue;
// 	color:white;
// }

// mainMenu 에서 li 와 a 두 선택자에서 mouseover 혹은 hover 이벤트 등록시 동일하게 color 변경
// css 로 구현은 했지만 동일한 상태 변경이 불가능
// jQuery로 구현 해봤지만 실행불가 --> 찾아봤지만 이유를 알수 없음
// mouseover + mouseout = hover




